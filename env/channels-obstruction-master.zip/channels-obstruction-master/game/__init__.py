default_app_config = 'game.apps.GameConfig'
