# Simple Background task using Django Channels

Code from this blog post: <a
href="http://albertoconnor.ca/blog/2016/May/18/django-channels-background-tasks">http://albertoconnor.ca/blog/2016/May/18/django-channels-background-tasks</a>
