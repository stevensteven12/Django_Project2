def hello(message):
    print("Hello, Channels!")  # long running task or printing

